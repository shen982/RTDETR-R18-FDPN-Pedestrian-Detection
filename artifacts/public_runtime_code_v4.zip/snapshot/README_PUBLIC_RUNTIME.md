# Public runtime code bundle

This archive is a path-safe, source-and-configuration derivative of the local
course-submission package. It includes the modified Ultralytics-derived runtime,
the attributed FDPN extraction, selected model graphs, split manifests, and
reproduction entry points. It excludes original dataset images, checkpoints,
raw run records containing machine paths, and the full experimental evidence.

The supplied FDPN module is redistributed on the maintainer's stated authority;
its topology remains attributed to the source bundle. Preserve all upstream
Ultralytics AGPL-3.0 and other third-party notices. This archive is not a
standalone, bit-for-bit environment. Consult the repository's LICENSES.md and
docs/REPRODUCTION.md before use. Load only trusted checkpoint files.

Extract this ZIP and the required weights_*.zip archive into the same fresh
parent directory; both use a snapshot/ prefix. Obtain Penn--Fudan, VOC2007, and
COCO2017 images from their original providers. Inside snapshot/, a safe check is:

    python scripts/submission_reproduce.py --action check --dataset penn --model baseline
    python scripts/submission_reproduce.py --action check --dataset penn --model fdpn

These checks do not load PyTorch models or allocate a GPU. New train/test runs
require compatible dependencies, prepared data, and a fresh output name.
